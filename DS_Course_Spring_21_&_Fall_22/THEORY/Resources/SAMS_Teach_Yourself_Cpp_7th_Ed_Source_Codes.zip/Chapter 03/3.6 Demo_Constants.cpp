#include <iostream>

int main()
{
   using namespace std;

   const double Pi = 22.0 / 7;
   cout << "The value of constant Pi is: " << Pi << endl;

   // Uncomment next line to fail compilation
   Pi = 3.14; 

   return 0;
}