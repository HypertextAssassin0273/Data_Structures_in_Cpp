#include <iostream>
using namespace std;

// Function declaration
int DemoConsoleOutput();

int main()
{
   // Call i.e. invoke the function
   DemoConsoleOutput();

   return 0;
}

// Function definition
int DemoConsoleOutput()
{
   cout << "Performing subtraction 10 - 5 = " << 10 - 5 << endl;
   cout << "Performing multiplication 10 * 5 = " << 10 * 5 << endl;

   return 0;
}

