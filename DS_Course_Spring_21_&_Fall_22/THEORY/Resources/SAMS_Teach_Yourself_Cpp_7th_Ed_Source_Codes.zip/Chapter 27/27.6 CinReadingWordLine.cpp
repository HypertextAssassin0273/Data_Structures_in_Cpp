#include<iostream>
#include<string>
using namespace std;

int main()
{
   cout << "Enter your name: ";
   string Name;
   cin >> Name;
   cout << "Hi " << Name << endl;

   return 0;
}